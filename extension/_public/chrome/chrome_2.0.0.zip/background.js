/*
 * Store initial data in local storage
 */
// chrome.runtime.onInstalled.addListener(() => {
//   chrome.storage.sync.set({
//     blur: {
//       checked: false,
//       value: 0,
//       unit: 'px'
//     },
//     brightness: {
//       checked: false,
//       value: 100,
//       unit: '%'
//     }
//   });
// });
